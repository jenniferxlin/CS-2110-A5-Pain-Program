
Jennifer Lin (jl3263)

1. Issues: I have a warning sign in my DrawingCanvas file. As I make my tool size bigger, the pencil and eraser creates a square on my first mouse press then smoothens out after I drag. 

2. I asked Albert Leung for help on debugging and received ideas on how to approach writing the methods after looking through questions that classmates asked and the answers that instructors and other students gave on Piazza.

3. For drawing the line and circle methods (TODO #15 and #17), I set the color to the foreground color and stroke size to toolSize by default to match with the specifications in methods (TODO #16 and #18). I also copied the code from TODO #11 to TODO #14, with both of them performing their respective functions correctly. 